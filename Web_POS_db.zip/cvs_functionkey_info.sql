-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: cvs
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `functionkey_info`
--

DROP TABLE IF EXISTS `functionkey_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `functionkey_info` (
  `key_no` varchar(45) NOT NULL,
  `md_name` varchar(45) NOT NULL,
  `barcode_no` int(11) NOT NULL,
  PRIMARY KEY (`key_no`),
  KEY `fk_fi` (`barcode_no`),
  CONSTRAINT `fk_fi` FOREIGN KEY (`barcode_no`) REFERENCES `md_info` (`barcode_no`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionkey_info`
--

LOCK TABLES `functionkey_info` WRITE;
/*!40000 ALTER TABLE `functionkey_info` DISABLE KEYS */;
INSERT INTO `functionkey_info` VALUES ('key_no1','새우깡',11131),('key_no10','불고기버거',11124),('key_no11','칠성사이다500',11155),('key_no12','',0),('key_no13','빠삐꼬',11128),('key_no14','스크류바',11135),('key_no15','월드콘',11145),('key_no16','',0),('key_no17','',0),('key_no18','',0),('key_no19','',0),('key_no2','',0),('key_no20','',0),('key_no21','',0),('key_no22','',0),('key_no23','',0),('key_no24','',0),('key_no25','',0),('key_no26','',0),('key_no27','',0),('key_no28','',0),('key_no29','',0),('key_no3','',0),('key_no30','',0),('key_no31','',0),('key_no32','',0),('key_no4','',0),('key_no5','',0),('key_no6','',0),('key_no7','',0),('key_no8','',0),('key_no9','',0);
/*!40000 ALTER TABLE `functionkey_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-11  9:23:38
