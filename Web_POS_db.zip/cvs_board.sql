-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: cvs
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(50) DEFAULT NULL,
  `content` longtext,
  `writer` varchar(10) DEFAULT NULL,
  `write_date` date DEFAULT NULL,
  `cnt` int(11) DEFAULT '0',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (56,'아이스크림 2+1행사 프로모션','<div><img style=\"width: 200px; height: 100px;\" src=\"../displayFile?fileName=/2020/03/10/2aeb9d72-a458-490d-bcaf-7cb39ba74f42_빠삐꼬.jpg\"><img src=\"../displayFile?fileName=/2020/03/10/5982af40-8656-47fc-9f1a-e4ac7c0abe91_스크류바.jpg\" style=\"font-size: 1rem; width: 200px; height: 100px;\"><img src=\"../displayFile?fileName=/2020/03/10/99850821-6b83-4e4c-9f8d-d9aa165d1665_월드콘.jpg\" style=\"font-size: 1rem; width: 200px; height: 100px;\"></div><div>빠삐꼬, 스크류바, 월드콘 2+1 할인행사 진행중 입니다.</div>','관리자','2020-03-10',2),(58,'마스크 품절 안내','KF-94 마스크 재고 부족으로 인해 마스크 발주가 힘든점 양해부탁드립니다.','관리자','2020-03-10',0),(59,'창업설명회 안내','<ul style=\"text-size-adjust: none; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px; border: 0px; font-size: 13.008px; vertical-align: top; color: rgb(30, 30, 30); list-style: none; overflow: hidden; font-family: &quot;Nanum Gothic&quot;, dotum, arial; letter-spacing: -0.6504px;\"><li style=\"text-size-adjust: none; margin: 0px; padding: 0px 0px 0px 9px; border: 0px; font-size: inherit; vertical-align: top; color: inherit; overflow: hidden; background: url(&quot;/images/icon/bullet_dot_01.gif&quot;) 0px 10px no-repeat;\">평일 : 화/금 오후2시(공휴일 미실시)</li><li style=\"text-size-adjust: none; margin: 0px; padding: 0px 0px 0px 9px; border: 0px; font-size: inherit; vertical-align: top; color: inherit; overflow: hidden; background: url(&quot;/images/icon/bullet_dot_01.gif&quot;) 0px 10px no-repeat;\">주말 : 매월 첫번째 /세번째 토요일 오전10시</li><li style=\"text-size-adjust: none; margin: 0px; padding: 0px 0px 0px 9px; border: 0px; font-size: inherit; vertical-align: top; color: inherit; overflow: hidden; background: url(&quot;/images/icon/bullet_dot_01.gif&quot;) 0px 10px no-repeat;\">2019년 : 12/7,21日<br style=\"text-size-adjust: none;\">2020년 : 01/4,18日, 02/8,22日, 03/7,21日, 04/4,18日<br style=\"text-size-adjust: none;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;05/9,23日, 06/6,20日, 07/4,18日, 08/8,22日<br style=\"text-size-adjust: none;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;09/5,19日, 10/3,17日, 11/7,21日, 12/5,19日</li><li class=\"caution\" style=\"text-size-adjust: none; margin: 0px; padding: 0px; border: 0px; font-size: inherit; vertical-align: top; color: inherit; overflow: hidden; background: url(&quot;none&quot;) 0px 0px no-repeat;\"><span class=\"txt_red\" style=\"text-size-adjust: none; margin: 0px; padding: 0px; border: 0px; font-size: inherit; vertical-align: top; color: rgb(234, 0, 0);\">※ 최소 1일전 사전신청 필수</span></li><li class=\"caution\" style=\"text-size-adjust: none; margin: 0px; padding: 0px; border: 0px; font-size: inherit; vertical-align: top; color: inherit; overflow: hidden; background: url(&quot;none&quot;) 0px 0px no-repeat;\"><span class=\"txt_red\" style=\"text-size-adjust: none; margin: 0px; padding: 0px; border: 0px; font-size: inherit; vertical-align: top; color: rgb(234, 0, 0);\"><br></span></li></ul>','관리자','2020-03-10',1),(60,'딸기샌드위치 발주지원금 안내','<div><img src=\"../displayFile?fileName=/2020/03/10/13851e65-e069-4300-8a43-6b4c9c46d98f_딸기샌드위치.jpg\" style=\"font-size: 1rem; width: 100px; height: 100px;\"><br></div><div><div>딸기샌드위치 발주 시 200원 발주지원금이 적용됩니다.<br></div><div><br></div></div>','관리자','2020-03-10',1),(61,'행사상품 할인적용','pos에 행사상품을 등록하면 자동으로 할인이 적용됩니다.','관리자','2020-03-10',0),(63,'상품등록방법','바코드번호를 직접 입력하거나 단축키를 이용하여 상품을 등록할 수&nbsp; 있습니다.','관리자','2020-03-10',0),(64,'상품발주방법','발주를 원하는 상품의 수량을 입력하고 저장한 후 관리자의 승인을 기다리면 발주가 완료됩니다.','관리자','2020-03-10',0),(65,'검품방법','관리자의 승인을 받은 후 발주받은 상품과 검품목록을 비교하며 개수에 이상이 없는지 체크합니다.','관리자','2020-03-10',0),(66,'환불안내','판매내역에서 원하는 거래번호를 선택하여 환불 버튼을 클릭하면 환불이 가능합니다.','관리자','2020-03-10',0),(67,'택배시스템 안내','택배시스템 도입을 고려하고 있습니다.','관리자','2020-03-10',0),(68,'가격변동안내','<div><img style=\"width: 100px; height: 100px;\" src=\"../displayFile?fileName=/2020/03/10/b76b482c-f41d-4753-b408-ae58e783002d_진로.jpg\"></div><div>진로클래식 판매량이 급증하여 200원 인상 예정입니다.</div>','관리자','2020-03-10',0),(69,'불고기버거, 펩시콜라 세트할인 프로모션','<div><img src=\"http://localhost:8081/cvs/displayFile?fileName=/2020/03/10/be08b31e-bb63-4237-ab31-ec9561ef6018_%EB%B6%88%EA%B3%A0%EA%B8%B0%EB%B2%84%EA%B1%B0.jpg\" style=\"font-size: 1rem; width: 100px; height: 100px;\"><img src=\"../displayFile?fileName=/2020/03/10/c5b8b647-3b0e-4ef6-8012-8836f1053724_펩시콜라.jpg\" style=\"font-size: 1rem; width: 100px; height: 100px;\"><br></div><div>불고기버거와 펩시콜라 세트 구매시 500원 할인이 적용됩니다.<br></div>','관리자','2020-03-10',8);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-05 23:25:31
