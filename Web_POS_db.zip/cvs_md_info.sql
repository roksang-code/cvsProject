-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: cvs
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `md_info`
--

DROP TABLE IF EXISTS `md_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_info` (
  `md_no` int(11) NOT NULL AUTO_INCREMENT,
  `barcode_no` int(11) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `detail_type` varchar(10) DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL,
  `md_name` varchar(50) DEFAULT NULL,
  `pack_date` date DEFAULT NULL,
  `shelf_life` int(11) DEFAULT NULL,
  `md_img` longtext,
  PRIMARY KEY (`barcode_no`),
  UNIQUE KEY `md_no_UNIQUE` (`md_no`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `md_info`
--

LOCK TABLES `md_info` WRITE;
/*!40000 ALTER TABLE `md_info` DISABLE KEYS */;
INSERT INTO `md_info` VALUES (1,11111,'냉동식품','만두','해태','고향만두','2020-03-10',365,'../displayFile?fileName=/고향만두.jpg'),(2,11112,'주류','맥주','기네스','기네스드레프트500','2020-03-10',365,'../displayFile?fileName=/기네스.jpg'),(3,11113,'신선식품','도시락','씨유푸드','내가초밥왕','2020-03-10',3,'../displayFile?fileName=/내가초밥왕.gif'),(4,11114,'신선식품','삼각김밥','혜왕푸드','듬뿍참치마요삼각김밥','2020-03-10',4,'../displayFile?fileName=/듬뿍참치마요네즈 삼각김밥.jpg'),(5,11115,'신선식품','샌드위치','씨유푸드','딸기샌드위치','2020-03-10',4,'../displayFile?fileName=/딸기샌드위치.jpg'),(6,11116,'담배','라이터','에이스','에이스라이터','2020-03-10',1000,'../displayFile?fileName=/라이터.jpg'),(7,11117,'담배','연초담배','말보로','말보로레드','2020-03-10',365,'../displayFile?fileName=/말보로레드.jpg'),(8,11118,'신선식품','햄버거','씨유푸드','매콤달콤칠리벅','2020-03-10',7,'../displayFile?fileName=/매콤달콤칠리벅.jpg'),(9,11119,'냉장식품','후랑크소세지','CJ','맥스봉청양고추','2020-03-10',14,'../displayFile?fileName=/맥스봉 청양고추 후랑크.jpg'),(10,11120,'사무용품','필기도구','모나미','컴퓨터싸인펜','2020-03-10',1000,'../displayFile?fileName=/모나미 컴퓨터싸인펜.jpg'),(11,11121,'사무용품','필기도구','모나미','모나미볼펜','2020-03-10',1000,'../displayFile?fileName=/모나미볼펜.jpg'),(12,11122,'음료','유음료','빙그레','바나나맛우유','2020-03-10',14,'../displayFile?fileName=/바나나맛우유.jpg'),(13,11123,'음료','유음료','빙그레','바나나맛우유라이트','2020-03-10',14,'../displayFile?fileName=/바나나맛우유라이트.jpg'),(14,11124,'신선식품','햄버거','시유푸드','불고기버거','2020-03-10',14,'../displayFile?fileName=/불고기버거.jpg'),(15,11125,'상온식품','컵라면','삼양','불닭볶음면','2020-03-10',180,'../displayFile?fileName=/불닭볶음면.jpg'),(16,11126,'기타','소모품','WP','비닐봉투','2020-03-10',0,'../displayFile?fileName=/비닐봉투.jpg'),(17,11127,'냉동식품','만두','비비고','비비고왕교자','2020-03-10',365,'../displayFile?fileName=/비비고왕교자.jpg'),(18,11128,'냉동식품','아이스크림','롯데','빠삐꼬','2020-03-10',0,'../displayFile?fileName=/빠삐꼬.jpg'),(19,11129,'상온식품','빵','삼립','단팥빵','2020-03-10',7,'../displayFile?fileName=/삼립단팥빵.jpg'),(20,11130,'상온식품','빵','삼립','크림빵','2020-03-10',7,'../displayFile?fileName=/삼립크림빵.jpg'),(21,11131,'상온식품','봉지류 과자','농심','새우깡','2020-03-10',90,'../displayFile?fileName=/새우깡.jpg'),(22,11132,'음료','유음료','서울우유','서울우유1L','2020-03-10',7,'../displayFile?fileName=/서울우유1L.jpg'),(23,11133,'음료','유음료','서울우유','서울우유딸기200','2020-03-10',7,'../displayFile?fileName=/서울우유딸기.jpg'),(24,11134,'신선식품','김밥','씨유푸드','숯불맛불고기김밥','2020-03-10',7,'../displayFile?fileName=/숯불맛불고기김밥.jpg'),(25,11135,'냉동식품','아이스크림','롯데','스크류바','2020-03-10',0,'../displayFile?fileName=/스크류바.jpg'),(26,11136,'사무용품','필기도구','스테들러','스테들러지우개','2020-03-10',0,'../displayFile?fileName=/스테들러지우개.jpg'),(27,11137,'신선식품','샌드위치','샌드팜','스파이스치킨샌드위치','2020-03-10',7,'../displayFile?fileName=/스파이시치킨샌드.jpg'),(28,11138,'사무용품','필기도구','WP','스프링노트','2020-03-10',0,'../displayFile?fileName=/스프링노트.jpg'),(29,11139,'상온식품','봉지라면','농심','신라면','2020-03-10',180,'../displayFile?fileName=/신라면.jpg'),(30,11140,'상온식품','봉지류 과자','농심','쌀새우깡','2020-03-10',90,'../displayFile?fileName=/쌀새우깡.jpg'),(31,11141,'주류','맥주','아사히','아사히500','2020-03-10',365,'../displayFile?fileName=/아사히.jpg'),(32,11142,'담배','연초담배','KT&G','에쎄체인지1','2020-03-10',365,'../displayFile?fileName=/에쎄체인지.jpg'),(33,11143,'상온식품','봉지라면','오뚜기','열라면','2020-03-10',90,'../displayFile?fileName=/열라면.JPG'),(34,11144,'상온식품','컵라면','팔도','왕뚜껑','2020-03-10',90,'../displayFile?fileName=/왕뚜껑.jpg'),(35,11145,'냉동식품','아이스크림','롯데','월드콘','2020-03-10',0,'../displayFile?fileName=/월드콘.jpg'),(36,11146,'상온식품','컵라면','농심','육개장사발면','2020-03-10',90,'../displayFile?fileName=/육개장 사발면.jpg'),(37,11147,'냉장식품','후랑크소세지','롯데햄','의성마늘프랑크','2020-03-10',30,'../displayFile?fileName=/의성마늘프랑크.jpg'),(38,11148,'사무용품','필기도구','제트스트림','제트스트림볼펜','2020-03-10',0,'../displayFile?fileName=/제트스트림.jpg'),(39,11149,'상온식품','봉지라면','오뚜기','진라면매운맛','2020-03-10',90,'../displayFile?fileName=/진라면 매운맛.jpg'),(40,11150,'상온식품','봉지라면','오뚜기','진라면순한맛','2020-03-10',90,'../displayFile?fileName=/진라면 순한맛.jpg'),(41,11151,'주류','소주','진로','진로클래식','2020-03-10',365,'../displayFile?fileName=/진로.jpg'),(42,11152,'주류','소주','진로','참이슬오리지널','2020-03-10',365,'../displayFile?fileName=/참이슬오리지널.jpg'),(43,11153,'주류','소주','진로','참이슬프레시','2020-03-10',365,'../displayFile?fileName=/참이슬프레시.jpg'),(44,11154,'신선식품','김밥','유어스푸드','참치마요김밥','2020-03-10',7,'../displayFile?fileName=/참치마요김밥.jpg'),(45,11155,'음료','탄산음료','칠성','칠성사이다500','2020-03-10',365,'../displayFile?fileName=/칠성사이다.jpg'),(46,11156,'주류','맥주','칭따오','칭따오500','2020-03-10',365,'../displayFile?fileName=/칭따오.jpg'),(47,11157,'주류','맥주','카스','카스프레시병500','2020-03-10',365,'../displayFile?fileName=/카스병맥주.jpg'),(48,11158,'상온식품','스낵&과자','롯데','칸쵸','2020-03-10',90,'../displayFile?fileName=/칸쵸.jpg'),(49,11159,'음료','탄산음료','코카콜라','코카콜라500','2020-03-10',365,'../displayFile?fileName=/코카콜라.jpg'),(50,11160,'음료','탄산음료','코카콜라','코카콜라제로190','2020-03-10',365,'../displayFile?fileName=/코카콜라제로.jpg'),(51,11161,'주류','맥주','하이트','테라병500','2020-03-10',365,'../displayFile?fileName=/테라병맥주.jpg'),(52,11162,'음료','탄산음료','펩시','펩시콜라180','2020-03-10',365,'../displayFile?fileName=/펩시콜라.jpg'),(53,11163,'상온식품','봉지류 과자','오리온','포카칩어니언','2020-03-10',90,'../displayFile?fileName=/포카칩.jpg'),(54,11164,'주류','맥주','호가든','호가든500','2020-03-10',365,'../displayFile?fileName=/호가든.jpg');
/*!40000 ALTER TABLE `md_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-05 23:25:36
