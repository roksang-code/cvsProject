-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: cvs
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `md_info`
--

DROP TABLE IF EXISTS `md_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `md_info` (
  `md_no` int(11) NOT NULL AUTO_INCREMENT,
  `barcode_no` int(11) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `detail_type` varchar(10) DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL,
  `md_name` varchar(50) DEFAULT NULL,
  `pack_date` date DEFAULT NULL,
  `shelf_life` int(11) DEFAULT NULL,
  `md_img` longtext,
  PRIMARY KEY (`barcode_no`),
  UNIQUE KEY `md_no_UNIQUE` (`md_no`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `md_info`
--

LOCK TABLES `md_info` WRITE;
/*!40000 ALTER TABLE `md_info` DISABLE KEYS */;
INSERT INTO `md_info` VALUES (1,11111,'냉동식품','만두','해태','고향만두','2020-03-10',365,'../displayFile?fileName=/2020/03/10/2312adde-2a45-4c42-bc75-71c49af28f3a_고향만두.jpg'),(2,11112,'주류','맥주','기네스','기네스드레프트500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/99275eab-dd72-487f-96ca-d414aac71a38_기네스.jpg'),(3,11113,'신선식품','도시락','씨유푸드','내가초밥왕','2020-03-10',3,'../displayFile?fileName=/2020/03/10/48b253b5-8f94-4dae-81de-07afacfcd14a_내가초밥왕.gif'),(4,11114,'신선식품','삼각김밥','혜왕푸드','듬뿍참치마요삼각김밥','2020-03-10',4,'../displayFile?fileName=/2020/03/10/7959a56b-a719-41e5-a609-7d4e6c3b4d58_듬뿍참치마요네즈 삼각김밥.jpg'),(5,11115,'신선식품','샌드위치','씨유푸드','딸기샌드위치','2020-03-10',4,'../displayFile?fileName=/2020/03/10/97b25504-0bad-4845-93dc-877b01dfeb96_딸기샌드위치.jpg'),(6,11116,'담배','라이터','에이스','에이스라이터','2020-03-10',1000,'../displayFile?fileName=/2020/03/10/3a172710-dd80-4946-b9e6-1bf00bc6cb33_라이터.jpg'),(7,11117,'담배','연초담배','말보로','말보로레드','2020-03-10',365,'../displayFile?fileName=/2020/03/10/ff58a834-c2e4-49d2-b912-55854e147ce0_말보로레드.jpg'),(8,11118,'신선식품','햄버거','씨유푸드','매콤달콤칠리벅','2020-03-10',7,'../displayFile?fileName=/2020/03/10/f7c62e47-80c8-4753-81f5-b234ff918e8c_매콤달콤칠리벅.jpg'),(9,11119,'냉장식품','후랑크소세지','CJ','맥스봉청양고추','2020-03-10',14,'../displayFile?fileName=/2020/03/10/ec70ddc0-44b6-4ff7-af87-08c38556d64c_맥스봉 청양고추 후랑크.jpg'),(10,11120,'사무용품','필기도구','모나미','컴퓨터싸인펜','2020-03-10',1000,'../displayFile?fileName=/2020/03/10/0c6e3f1e-70ca-43de-af09-4e7861fae3ae_모나미 컴퓨터싸인펜.jpg'),(11,11121,'사무용품','필기도구','모나미','모나미볼펜','2020-03-10',1000,'../displayFile?fileName=/2020/03/10/7068860d-4a27-49f7-948c-85b95927e349_모나미볼펜.jpg'),(12,11122,'음료','유음료','빙그레','바나나맛우유','2020-03-10',14,'../displayFile?fileName=/2020/03/10/8e58f710-d4ea-44ad-a1de-032f0aaf62e0_바나나맛우유.jpg'),(13,11123,'음료','유음료','빙그레','바나나맛우유라이트','2020-03-10',14,'../displayFile?fileName=/2020/03/10/e2e2dedc-81c9-4f85-b593-d67aa00097f7_바나나맛우유라이트.jpg'),(14,11124,'신선식품','햄버거','시유푸드','불고기버거','2020-03-10',14,'../displayFile?fileName=/2020/03/10/5123f5ea-9bde-4a33-9e1a-743fb8a354e9_불고기버거.jpg'),(15,11125,'상온식품','컵라면','삼양','불닭볶음면','2020-03-10',180,'../displayFile?fileName=/2020/03/10/c32938be-5664-4643-bf74-ea9473846e58_불닭볶음면.jpg'),(16,11126,'기타','소모품','WP','비닐봉투','2020-03-10',0,'../displayFile?fileName=/2020/03/10/2043c8d4-9e13-400e-a1cc-cb15df338901_비닐봉투.jpg'),(17,11127,'냉동식품','만두','비비고','비비고왕교자','2020-03-10',365,'../displayFile?fileName=/2020/03/10/d8106c1f-0f50-47fc-88b6-3ddb74a8ca14_비비고왕교자.jpg'),(18,11128,'냉동식품','아이스크림','롯데','빠삐꼬','2020-03-10',0,'../displayFile?fileName=/2020/03/10/9c28bd45-3c49-4531-9aeb-1ab0d913d12f_빠삐꼬.jpg'),(19,11129,'상온식품','빵','삼립','단팥빵','2020-03-10',7,'../displayFile?fileName=/2020/03/10/66ffbe8e-d411-4e9a-a509-354bb239de6c_삼립단팥빵.jpg'),(20,11130,'상온식품','빵','삼립','크림빵','2020-03-10',7,'../displayFile?fileName=/2020/03/10/0c277040-e6ea-4f46-9417-ef7cfbbe1f6a_삼립크림빵.jpg'),(21,11131,'상온식품','봉지류 과자','농심','새우깡','2020-03-10',90,'../displayFile?fileName=/2020/03/10/62402cb9-4210-43a7-bcdd-486c6e927cb3_새우깡.jpg'),(22,11132,'음료','유음료','서울우유','서울우유1L','2020-03-10',7,'../displayFile?fileName=/2020/03/10/e9509e3f-8d5c-4821-9b75-828c6e01cd60_서울우유1L.jpg'),(23,11133,'음료','유음료','서울우유','서울우유딸기200','2020-03-10',7,'../displayFile?fileName=/2020/03/10/18599de7-7d2b-458f-b1d3-cbbb3fe4288f_서울우유딸기.jpg'),(24,11134,'신선식품','김밥','씨유푸드','숯불맛불고기김밥','2020-03-10',7,'../displayFile?fileName=/2020/03/10/a2a8af6e-4f0c-47ae-b35f-c009b64d2ad3_숯불맛불고기김밥.jpg'),(25,11135,'냉동식품','아이스크림','롯데','스크류바','2020-03-10',0,'../displayFile?fileName=/2020/03/10/428f8969-d110-4665-b643-24a17a925b4c_스크류바.jpg'),(26,11136,'사무용품','필기도구','스테들러','스테들러지우개','2020-03-10',0,'../displayFile?fileName=/2020/03/10/1b3bb938-892a-40de-95e3-5b17923d3c04_스테들러지우개.jpg'),(27,11137,'신선식품','샌드위치','샌드팜','스파이스치킨샌드위치','2020-03-10',7,'../displayFile?fileName=/2020/03/10/5a3e8163-430f-44e4-b860-d5f709436239_스파이시치킨샌드.jpg'),(28,11138,'사무용품','필기도구','WP','스프링노트','2020-03-10',0,'../displayFile?fileName=/2020/03/10/b815f88a-27cb-4600-97f8-94359b070469_스프링노트.jpg'),(29,11139,'상온식품','봉지라면','농심','신라면','2020-03-10',180,'../displayFile?fileName=/2020/03/10/92ed2819-9de7-4e6b-ab59-4f2734b6a2e8_신라면.jpg'),(30,11140,'상온식품','봉지류 과자','농심','쌀새우깡','2020-03-10',90,'../displayFile?fileName=/2020/03/10/3d36a06c-0eab-4027-8935-6b31d269d99c_쌀새우깡.jpg'),(31,11141,'주류','맥주','아사히','아사히500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/46313f48-d4dd-4bea-92ac-ee7b9c1b0eef_아사히.jpg'),(32,11142,'담배','연초담배','KT&G','에쎄체인지1','2020-03-10',365,'../displayFile?fileName=/2020/03/10/2a15ec91-b3ee-45ed-8c56-6a6f0db1772a_에쎄체인지.jpg'),(33,11143,'상온식품','봉지라면','오뚜기','열라면','2020-03-10',90,'../displayFile?fileName=/2020/03/10/ff7d87d5-afe1-46e0-a486-15e47e572706_열라면.JPG'),(34,11144,'상온식품','컵라면','팔도','왕뚜껑','2020-03-10',90,'../displayFile?fileName=/2020/03/10/1aa600c1-8f43-491e-97b3-36ebfefb3893_왕뚜껑.jpg'),(35,11145,'냉동식품','아이스크림','롯데','월드콘','2020-03-10',0,'../displayFile?fileName=/2020/03/10/4d43b678-05de-413a-b8bb-b9a72c3d7c65_월드콘.jpg'),(36,11146,'상온식품','컵라면','농심','육개장사발면','2020-03-10',90,'../displayFile?fileName=/2020/03/10/5bdd72f8-a849-439b-9704-b3c9b024fda3_육개장 사발면.jpg'),(37,11147,'냉장식품','후랑크소세지','롯데햄','의성마늘프랑크','2020-03-10',30,'../displayFile?fileName=/2020/03/10/0b6898e5-c9d7-455c-85fc-2900c9e7ec0b_의성마늘프랑크.jpg'),(38,11148,'사무용품','필기도구','제트스트림','제트스트림볼펜','2020-03-10',0,'../displayFile?fileName=/2020/03/10/ef7fdf1c-541d-4412-a7ec-9fea61e749d4_제트스트림.jpg'),(39,11149,'상온식품','봉지라면','오뚜기','진라면매운맛','2020-03-10',90,'../displayFile?fileName=/2020/03/10/3907575b-0012-4e10-9da5-9df7078f8916_진라면 매운맛.jpg'),(40,11150,'상온식품','봉지라면','오뚜기','진라면순한맛','2020-03-10',90,'../displayFile?fileName=/2020/03/10/496538ef-5e3a-4092-9629-b357ae1e5100_진라면 순한맛.jpg'),(41,11151,'주류','소주','진로','진로클래식','2020-03-10',365,'../displayFile?fileName=/2020/03/10/10d71114-0b79-4929-8d89-114f58653513_진로.jpg'),(42,11152,'주류','소주','진로','참이슬오리지널','2020-03-10',365,'../displayFile?fileName=/2020/03/10/e46cf979-1130-4aac-b612-dbae88e1fcce_참이슬오리지널.jpg'),(43,11153,'주류','소주','진로','참이슬프레시','2020-03-10',365,'../displayFile?fileName=/2020/03/10/d49e556c-b8d1-4acb-a240-a30e75f3d7bc_참이슬프레시.jpg'),(44,11154,'신선식품','김밥','유어스푸드','참치마요김밥','2020-03-10',7,'../displayFile?fileName=/2020/03/10/b189c386-3c4c-43c6-8ddb-82fc9697092a_참치마요김밥.jpg'),(45,11155,'음료','탄산음료','칠성','칠성사이다500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/4836e922-4e58-445c-a5e6-70b72a4dabf2_칠성사이다.jpg'),(46,11156,'주류','맥주','칭따오','칭따오500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/b0b49554-3077-41ea-b00d-5f8b49445d05_칭따오.jpg'),(47,11157,'주류','맥주','카스','카스프레시병500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/c5253701-3d51-4950-8ff7-20c071ee6a0c_카스병맥주.jpg'),(48,11158,'상온식품','스낵&과자','롯데','칸쵸','2020-03-10',90,'../displayFile?fileName=/2020/03/10/99d7051f-3f9a-412f-931b-1c49f3d74023_칸쵸.jpg'),(49,11159,'음료','탄산음료','코카콜라','코카콜라500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/4b2d5bfb-7ccb-4346-9164-01d7a2b276dd_코카콜라.jpg'),(50,11160,'음료','탄산음료','코카콜라','코카콜라제로190','2020-03-10',365,'../displayFile?fileName=/2020/03/10/2b54c858-bc6c-461d-a0c0-5601d2ec8723_코카콜라제로.jpg'),(51,11161,'주류','맥주','하이트','테라병500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/7212f491-7467-4093-bf2e-04f6f94019cf_테라병맥주.jpg'),(52,11162,'음료','탄산음료','펩시','펩시콜라180','2020-03-10',365,'../displayFile?fileName=/2020/03/10/de414e2c-b24f-455b-9d6d-b1956a866e94_펩시콜라.jpg'),(53,11163,'상온식품','봉지류 과자','오리온','포카칩어니언','2020-03-10',90,'../displayFile?fileName=/2020/03/10/56677ac1-ae51-47b7-8ef7-dbce2fa72c20_포카칩.jpg'),(54,11164,'주류','맥주','호가든','호가든500','2020-03-10',365,'../displayFile?fileName=/2020/03/10/82d512dd-c073-4a59-bb38-c9bd8b43c145_호가든.jpg');
/*!40000 ALTER TABLE `md_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-11  9:23:48
